public class proba {
    public static void main(String[] args) {
        char ch = (char) (654);
        System.out.println(ch);
        System.out.println((int) ch);
    }
    
}
